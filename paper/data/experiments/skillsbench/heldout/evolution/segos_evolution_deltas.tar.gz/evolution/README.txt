Held-out (50 train / 37 eval) evolution deltas.

Regenerated with the avoid relation enabled at its default evidence bar
(AVOID_FAIL_MIN=1) and the non-contradiction invariant on.

delta_L1L2L3_L1.json  topology: 127 workflow edges added, 9 avoid edges, semantic pruning
delta_L1L2L3_L2.json  Hebbian reinforcement
delta_L1L2L3_L3.json  3 description rewrites, carried over from the reported run
signals.json          parsed traces, already filtered to the 50 training tasks

Apply in L1 -> L2 -> L3 order to coldstart/segos_coldstart_skills1000.json to
reproduce heldout/graphs/segos_evolved_skills1000_heldout_train50.json (999 edges).

L1 and L2 are recomputed deterministically from the traces. L3 rewrites
descriptions with an LLM call, so its delta is carried over from the reported
run rather than recomputed; a fresh evolution pass may rewrite a different set.
